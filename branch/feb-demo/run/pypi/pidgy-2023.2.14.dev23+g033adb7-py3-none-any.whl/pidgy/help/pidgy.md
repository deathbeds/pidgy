# you're in `pidgy` mode

`pidgy` is an interactive programming experience in markdown. you

## pidgy methods

## helpful links

* [CommonMark Spec]

[CommonMark Spec]: https://spec.commonmark.org/0.30/ "CommonMark Spec v0.30"